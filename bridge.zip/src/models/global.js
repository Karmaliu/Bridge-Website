export default {
    namespace:"global",
    state:{
        aaa:''
    }
}