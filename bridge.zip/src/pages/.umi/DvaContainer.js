import { Component } from 'react';
import dva from 'dva';
import createLoading from 'dva-loading';

let app = dva({
  history: window.g_history,
  ...((require('f:/bridge/src/dva.js').config || (() => ({})))()),
});

window.g_app = app;
app.use(createLoading());

app.model({ namespace: 'global', ...(require('f:/bridge/src/models/global.js').default) });
app.model({ namespace: 'user', ...(require('f:/bridge/src/models/user.js').default) });
app.model({ namespace: 'games', ...(require('f:/bridge/src/pages/management/match/models/games.js').default) });

class DvaContainer extends Component {
  render() {
    app.router(() => this.props.children);
    return app.start()();
  }
}

export default DvaContainer;
