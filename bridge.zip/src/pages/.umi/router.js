import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';


let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import('../../layouts/index.js') }),
    "routes": [
      {
        "path": "/sponsor",
        "exact": true,
        "component": dynamic({ loader: () => import('../sponsor/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/home",
        "exact": true,
        "component": dynamic({ loader: () => import('../home.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/info",
        "exact": false,
        "component": dynamic({ loader: () => import('../info/_layout.js') }),
        "routes": [
          {
            "path": "/info/backcard",
            "exact": true,
            "component": dynamic({ loader: () => import('../info/backcard.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/info/contact",
            "exact": true,
            "component": dynamic({ loader: () => import('../info/contact.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/info/id",
            "exact": true,
            "component": dynamic({ loader: () => import('../info/id.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/info",
            "exact": true,
            "component": dynamic({ loader: () => import('../info/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/info/modifyPwd",
            "exact": true,
            "component": dynamic({ loader: () => import('../info/modifyPwd.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
            "_title": "myumi",
            "_title_default": "myumi"
          }
        ],
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/game",
        "exact": false,
        "component": dynamic({ loader: () => import('../game/_layout.js') }),
        "routes": [
          {
            "path": "/game/gameNational",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/gameNational.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/gameseatch",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/gameseatch.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/gamelocal",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/gamelocal.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/review",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/review.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/reviewclub",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/reviewclub.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/reviewlocal",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/reviewlocal.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/reviewNational",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/reviewNational.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/gameclub",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/gameclub.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game/trailnotice",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/trailnotice.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/game",
            "exact": true,
            "component": dynamic({ loader: () => import('../game/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
            "_title": "myumi",
            "_title_default": "myumi"
          }
        ],
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/management",
        "exact": false,
        "component": dynamic({ loader: () => import('../management/_layout.js') }),
        "routes": [
          {
            "path": "/management/advertise",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/advertise.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management/match/creat",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/match/creat.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management/match/data",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/match/data.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management/match/gameinfo",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/match/gameinfo.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management/match/gameView",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/match/gameView.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management/match",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/match/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/management/sponsor",
            "exact": true,
            "component": dynamic({ loader: () => import('../management/sponsor/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
            "_title": "myumi",
            "_title_default": "myumi"
          }
        ],
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/details",
        "exact": false,
        "component": dynamic({ loader: () => import('../details/_layout.js') }),
        "routes": [
          {
            "path": "/details/dhome",
            "exact": true,
            "component": dynamic({ loader: () => import('../details/dhome.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/details/data",
            "exact": true,
            "component": dynamic({ loader: () => import('../details/data.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/details/grade",
            "exact": false,
            "component": dynamic({ loader: () => import('../details/grade/_layout.js') }),
            "routes": [
              {
                "path": "/details/grade/1",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/1/index.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/1/play",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/1/play.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/2",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/2/index.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/datumn",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/datumn/index.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/index.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/graresult",
                "exact": false,
                "component": dynamic({ loader: () => import('../details/grade/graresult/_layout.js') }),
                "routes": [
                  {
                    "path": "/details/grade/graresult",
                    "exact": true,
                    "component": dynamic({ loader: () => import('../details/grade/graresult/index.js') }),
                    "_title": "myumi",
                    "_title_default": "myumi"
                  },
                  {
                    "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
                    "_title": "myumi",
                    "_title_default": "myumi"
                  }
                ],
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/round",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/round/index.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/score",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/score/index.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "path": "/details/grade/score/rank",
                "exact": true,
                "component": dynamic({ loader: () => import('../details/grade/score/rank.js') }),
                "_title": "myumi",
                "_title_default": "myumi"
              },
              {
                "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
                "_title": "myumi",
                "_title_default": "myumi"
              }
            ],
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/details/join",
            "exact": true,
            "component": dynamic({ loader: () => import('../details/join/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/details/news",
            "exact": true,
            "component": dynamic({ loader: () => import('../details/news.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/details/team",
            "exact": true,
            "component": dynamic({ loader: () => import('../details/team.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "path": "/details",
            "exact": true,
            "component": dynamic({ loader: () => import('../details/index.js') }),
            "_title": "myumi",
            "_title_default": "myumi"
          },
          {
            "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
            "_title": "myumi",
            "_title_default": "myumi"
          }
        ],
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/bridge",
        "exact": true,
        "component": dynamic({ loader: () => import('../bridge/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/news",
        "exact": true,
        "component": dynamic({ loader: () => import('../news/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/live",
        "exact": true,
        "component": dynamic({ loader: () => import('../live/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/mall",
        "exact": true,
        "component": dynamic({ loader: () => import('../mall/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/user/forget",
        "exact": true,
        "component": dynamic({ loader: () => import('../user/forget.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/user/info",
        "exact": true,
        "component": dynamic({ loader: () => import('../user/info.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/user/login",
        "exact": true,
        "component": dynamic({ loader: () => import('../user/login.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/user/register",
        "exact": true,
        "component": dynamic({ loader: () => import('../user/register.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/community",
        "exact": true,
        "component": dynamic({ loader: () => import('../community/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/vip",
        "exact": true,
        "component": dynamic({ loader: () => import('../vip/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "path": "/join",
        "exact": true,
        "component": dynamic({ loader: () => import('../join/index.js') }),
        "_title": "myumi",
        "_title_default": "myumi"
      },
      {
        "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
        "_title": "myumi",
        "_title_default": "myumi"
      }
    ],
    "_title": "myumi",
    "_title_default": "myumi"
  },
  {
    "component": () => React.createElement(require('f:/bridge/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: false }),
    "_title": "myumi",
    "_title_default": "myumi"
  }
];

export default function() {
  return (
<Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
  );
}
