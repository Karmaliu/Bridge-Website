import { Component } from "react";
import { Table } from 'antd'
import moment from 'moment';
const dataSource = [{
    key: '1',
    name: '比赛1',
    expiration:new Date(`2017-07-01 `),
    start: new Date(),
    status:'进行中'
  }, {
    key: '2',
    name: '比赛2',
    expiration: new Date(),
    start: new Date(),
    status:'已结束'
  }];
  
  const columns = [{
    title: '比赛名称',
    dataIndex: 'name',
    key: 'name',
  }, {
    title: '报名截止时间',
    dataIndex: 'expiration',
    key: 'expiration',
    render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
  }, {
    title: '开始时间',
    dataIndex: 'start',
    key: 'start',
    render: val => <span>{moment(val).format('YYYY-MM-DD HH:mm:ss')}</span>,
  },{
    title: '状态',
    dataIndex: 'status',
    key: 'status',
  }];

export default class TableList extends Component{
    constructor(props){
        super(props)
    }
    
    render(){
        return (
            <Table dataSource={dataSource} columns={columns}/>
        )
    }
}