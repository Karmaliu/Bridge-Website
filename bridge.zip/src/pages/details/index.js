import { Redirect } from "dva/router";

export default ()=>(<Redirect to='/details/dhome'/>)