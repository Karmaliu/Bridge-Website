export const headerRoutes = [
    {
        name: "首页",
        path: "/home",
        child: [],
    }, {
        name: "赛事",
        path: "/game",
        child: [{
            name: "赛事预告",
            path: "/trailnotice",
            icon: "tablet",
            child: [{
                name: "全国",
                path: "/gameNational",
                child: [],
            }, {
                name: "地方",
                path: "/gamelocal",
                child: [],
            }, {
                name: "俱乐部",
                path: "/gameclub",
                child: [],
            }]
        }, {
            name: "赛事回顾",
            path: "/review",
            icon: "table",
            child: [{
                name: "全国",
                path: "/reviewNational",
                child: [],
            }, {
                name: "地方",
                path: "/reviewlocal",
                child: [],
            }, {
                name: "俱乐部",
                path: "/reviewclub",
                child: [],
            }]
        }, {
            name: "赛事查询",
            path: "/gameseatch",
            icon: "file-search",
            child: [],
        }
        ]
    },{
        name:'直播',
        path:'/live',
        child:[]
    },
    {
        name:'新闻',
        path:'/news',
        child:[]
    },
    {
        name:'桥协',
        path:'/bridge',
        child:[]
    },
    {
        name:'会员',
        path:'/vip',
        child:[]
    },
    {
        name:'商城',
        path:'/mall',
        child:[]
    },
    {
        name:'社区',
        path:'/community',
        child:[]
    },
    {
        name:'主办方',
        path:'/sponsor',
        authority:'sponsor',
        child:[]
    },
    {
        name:'后台管理',
        path:'/management',
        authority:'management',
        child:[]
    }
]
