const managementRouter=[
    {name:"比赛",path:"/management/match"},
    {name:"主办方",path:"/management/sponsor"},
    {name:"广告商",path:"/management/advertise"},
]

export default managementRouter;