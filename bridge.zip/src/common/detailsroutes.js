export const details = [
    {
        name: '首页',
        path: '/dhome',
        child: [],
    }, {
        name: '参赛队',
        path: '/team',
        child: [],
    }, {
        name: "成绩",
        path: '/grade',
        child: [],
    }, {
        name: "数据",
        path: "/data",
        child: [],
    }, {
        name: "新闻",
        path: "/news",
        child: [],
    }
]
